function Point(x, y)
{
	this.x = x;
	this.y = y;
}
function Rect(left, top, width, height)
{
	this.left = left;
	this.top = top;
	this.width = width;
	this.height = height;
	this.right = this.left + width;
	this.bottom = this.top + height;
	this.topLeft = new Point(this.left, this.top);
	this.bottomRight = new Point(this.right, this.bottom);
}
