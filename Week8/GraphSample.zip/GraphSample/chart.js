// ChartAxis class; helper for Chart class
function ChartAxis(legend, gridtickstep, gridlabelstep)
{
	this.legend = legend;
	this.grid = {
		tickstep:gridtickstep,
		labelstep:gridlabelstep
	};
}

// Chart class
function Chart(id, title, xAxis, yAxis)
{
	var self = this; 
	self.id = id;
	self.title = title;
	self.xAxis = xAxis;
	self.yAxis = yAxis;
	self.dataRect = new Rect(0,0,0,0);

    self.canvas = document.getElementById(id);
    self.context = self.canvas.getContext("2d");
	
	self.createBackground();
}

Chart.prototype.clear = function()
{
	this.canvas.height = this.canvas.height;
}

Chart.prototype.createBackground = function()
{
	var _titleFont = "12pt arial";
	var _legendFont = "italic 9pt arial";
	var _gridFont = "9pt arial";
	var _gridmargin = 4;

	var self = this;
    var canvas = self.canvas;
    var ctx = self.context;
	//ctx.save();
	
	// Draw a border around the entire chart & fill the background white
	ctx.strokeStyle = "#000";
	crispRect(ctx, new Rect(0, 0, canvas.width, canvas.height));
	ctx.fillStyle = '#fff';
	ctx.fillRect(1, 1, canvas.width-2, canvas.height-2);
	
	// Grid bounds
	var gridLeft = 50;	// Includes labels & legend
	var gridTop = 30;	// Includes title
	var gridWidth = canvas.width - (gridLeft + 30);	// 30 = right margin
	var gridHeight = canvas.height - (gridTop + 40);// 40 = bottom margin; includes labels & legend
	var gridBottom = gridTop + gridHeight;
	var gridRight = gridLeft + gridWidth;

	// The bounding rectangle of the chart's data area
	self.dataRect = new Rect(gridLeft+_gridmargin, 
							gridTop+_gridmargin, 
							gridWidth-(2*_gridmargin), 
							gridHeight-(2*_gridmargin));
	
	// Chart title
	ctx.font = _titleFont;
	ctx.fillStyle = '#000';	// Black
	ctx.textAlign = "center";
	ctx.textBaseline = "top";
	ctx.fillText(self.title, canvas.width/2, 6);

	// Draw inner grid in gray
    ctx.strokeStyle = "#ddd";

	// Y-AXIS
	
	// Ticks
	for(var y=gridBottom-1; y>gridTop; y -= self.yAxis.grid.tickstep) {
		crispLine(ctx, new Point(gridLeft-_gridmargin, y), new Point(gridLeft, y));
	}
	
	// Gridlines
	ctx.font = _gridFont;
	ctx.fillStyle = '#000';
	ctx.textAlign = "right";
	ctx.textBaseline = "middle";
	var inc = self.yAxis.grid.labelstep;
	for(var y=gridBottom-1; y>gridTop; y -= inc) {
		crispLine(ctx, new Point(gridLeft, y), new Point(gridRight, y));
		lbltext = gridBottom-y-1;
		ctx.fillText(lbltext, gridLeft-(2*_gridmargin), y+1);
	}

	// Legend (drawn vertically)
	ctx.font = _legendFont;
	ctx.fillStyle = '#000';
	ctx.textAlign = "center";
	ctx.textBaseline = "top";
	ctx.rotate(-Math.PI/2);
	var y = canvas.height / 2;
	ctx.fillText(self.yAxis.legend, 0-y, 6);
	ctx.rotate(Math.PI/2);	// de-rotate
	
	// X-AXIS
	// Ticks
	var inc = self.xAxis.grid.tickstep;
	for(var x=gridLeft; x<gridRight; x += inc) {
		crispLine(ctx, new Point(x, gridBottom), new Point(x, gridBottom+_gridmargin) );
	}

	// Gridlines
	ctx.font = _gridFont;
	ctx.fillStyle = '#000';
	ctx.textAlign = "center";
	ctx.textBaseline = "top";
	for(var x=gridLeft; x<gridRight; x += self.xAxis.grid.labelstep) {
		crispLine(ctx, new Point(x, gridTop), new Point(x, gridBottom) );
		lbltext = x-gridLeft;
		ctx.fillText(lbltext, x, gridBottom+(2*_gridmargin));
	}

	// Legend
	ctx.font = _legendFont;
	ctx.fillStyle = '#000';
	ctx.textBaseline = "bottom";
	ctx.fillText(self.xAxis.legend, gridLeft + gridWidth/2, canvas.height-_gridmargin);

	// Finally, draw the grid's bounding rect
    ctx.strokeStyle = "#999";
	crispRect(ctx, new Rect(gridLeft, gridTop, gridWidth, gridHeight));

	ctx.restore();

	// Grab the content that we drew as a base64 PNG
	// This will allow us to draw & erase the canvas without losing the background
	var base64 = canvas.toDataURL();	// Grab the canvas as a PNG
	// ..  and stuff the PNG into the element's background
	canvas.style.backgroundImage = "url("+base64+")";

	// Erase the canvas.
	// This clears the canvas element but *not* the background image
	self.clear();
}
