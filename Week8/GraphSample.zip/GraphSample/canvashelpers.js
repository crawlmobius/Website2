// Canvas helpers
function crispLine(context, p1, p2)
{
	// Make local vars; don't alter the passed-in p1 or p2
	var x1 = p1.x;
	var x2 = p2.x;
	var y1 = p1.y;
	var y2 = p2.y;
	
	if(x1 == x2)
	{
		x1 = Math.round(x1) + 0.5;
		x2 = x1;
	}
	else if(y1 == y2)
	{
		y1 = Math.round(y1) + 0.5;
		y2 = y1;
	}

    context.beginPath();
    context.moveTo(x1, y1);
    context.lineTo(x2, y2);
    context.stroke();
}

function crispRect(context, rc)
{
	var rcx = new Rect(rc.left, rc.top, rc.width-1, rc.height-1);
	
	var topRight = new Point(rcx.right, rcx.top);
	var bottomLeft = new Point(rcx.left, rcx.bottom);
	
	crispLine(context, rcx.topLeft, topRight);
	crispLine(context, topRight, new Point(rcx.right, rcx.bottom+1));
	crispLine(context, rcx.bottomRight, bottomLeft);
	crispLine(context, bottomLeft, rcx.topLeft);
}
